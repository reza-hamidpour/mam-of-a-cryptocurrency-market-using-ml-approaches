import asyncio as asy
from clasess.database import Database
from clasess.cumpute_change_in_inventory_15_minuets_final import ComputeChangeInInventory
from clasess.user_amount_in_15_minuets_final import userAmountIn15Minuets


async def compute_user_working_capital(asset, opening_time, closing_time):
    db_handler = Database()
    working_collection = asset + "_user_working_capital_selling_per_15_minuets"
    working_db = db_handler.select_another_db("stellar_result")
    operations = db_handler.select_collection(asset + "_bucket")
    UWC = userAmountIn15Minuets(operations, working_db, working_collection, asset, opening_time, closing_time)
    UWC.get_users()
    await UWC.handel_users()


loop  = asy.get_event_loop()
loop.run_until_complete(compute_user_working_capital("native", "2019-10-09T15:30:38Z", "2019-12-15T14:26:38Z"))
loop.close()
